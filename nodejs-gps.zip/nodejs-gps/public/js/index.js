$(document).ready(function() {

    $("form").submit(function(e) {
        e.preventDefault(e);
        sendMessage();
    });

    function sendMessage() {
        const message = $("#message").val();
        const data = { message: message };
        // send 푸시 알림 메세지 처리를 위해 서버 URL에 POST요청 생성함
        $.post("/send-message", data, function() {
            addMessageToList(data.message);
        }).fail(function(error) {
            const firstError = error.responseJSON["errors"][0]["msg"];
            alert(firstError);
        });
    }

    function addMessageToList(message) {
        $("#sentMessages").prepend(`<li class="list-group-item">${message}</li>`);
    }

});