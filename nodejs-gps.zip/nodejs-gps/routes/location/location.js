// routes/location/location.js
const express = require('express');
const router = express.Router();
const mysql = require("mysql2");
const bodyParser = require('body-parser');

const db = mysql.createConnection({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASS,
    database: process.env.DB_NAME
});
db.connect();

router.use(bodyParser.json());

// 삽입
router.post("/", (req, res) => {
        var sql = 'INSERT INTO location VALUES (?,?,?)';
        var params = [req.body.device_id, req.body.latitude, req.body.longitude];

        db.query(sql, params, (error, rows) => {
            if (error) throw error;
            console.log('[post]Location info is: ', rows);
            res.send(rows);
        });
    })
    // 조회
router.get("/", (req, res) => {
    db.query('SELECT * FROM location', (error, rows) => {
        if (error) throw error;
        console.log('[get]Location info is: ', rows);
        res.send(rows);
    });
});
router.get("/:device_id", (req, res) => {
    db.query(`SELECT * FROM location WHERE device_id=\'${req.params.device_id}\'`, (error, rows) => {
        if (error) throw error;
        console.log('[get]Location info is: ', rows);
        res.send(rows)
    });
});
// 수정
router.put("/:device_id", (req, res) => {
        var sql = 'UPDATE location SET latitude=' + req.body.latitude + ', longitude=' + req.body.longitude + ' WHERE device_id=\'' + req.params.device_id + "\'";
        db.query(sql, (error, rows) => {
            if (error) throw error;
            console.log('[put]Location info is: ', rows);
            res.send(rows);
        });
    })
    // 삭제
router.delete("/:device_id", (req, res) => {
    var sql = 'DELETE FROM location WHERE device_id=\'' + req.params.device_id + '\'';
    db.query(sql, (error, rows) => {
        if (error) throw error;
        console.log('[delete]Location info is: ', rows);
        res.send(rows);
    });
})

module.exports = router;