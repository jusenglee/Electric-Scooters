const express = require('express');
const router = express.Router();
const mysql = require("mysql2");
const bodyParser = require('body-parser');

const db = mysql.createConnection({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASS,
    database: process.env.DB_NAME
});
db.connect();

router.use(bodyParser.json());

router.get("/", (req, res) => {
    let data;
    const device_id = 1;
    db.query('SELECT * FROM location WHERE device_id=\'' + device_id + '\'', (error, rows) => {
        if (error) throw error;
        data = rows;

        res.render('map', { lat: data[0].latitude, lng: data[0].longitude });
    });
});

module.exports = router;